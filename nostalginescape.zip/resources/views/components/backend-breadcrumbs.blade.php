<li class="breadcrumb-item"><a href="{{route('backend.dashboard')}}"><i class="fa-solid fa-cubes"></i> {{__('Dashboard')}}</a></li>

{!! $slot !!}