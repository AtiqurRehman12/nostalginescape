<?php

return [
    'name' => 'Info',
];
